rows(4).
columns(4).
num(1,4,2).
num(2,1,2).
num(3,2,2).
num(4,1,1).
num(4,2,2).
