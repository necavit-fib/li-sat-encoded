/*****************************************************************/
/*                   Number Cicle Wrap Solver                    */
/*****************************************************************/

LI - Novembre 2013
David Martínez Rodríguez

david.martinez.rodriguez@est.fib.upc.edu

There are two directories in this zipped file:
-automated_solver: it contains a shell script to help automate
    the build process of the solver.
    There is a subdirectory named 'instances' with the problem
    instances given.

-plain_prolog: contains the necessary Prolog program and a Makefile
    to compile and execute manualy the solver.


AUTOMATED SOLVER
  The script can be executed as:
    i)  $> number_cicle_wrap.sh -s symbolic.out instance.pro
      executes the solver symbolically on the symbolic.out file
      over a given instance.
      
    ii) $> number_cicle_wrap.sh instance.pro
      executes the solver over a given instance, showing the
      solution of the model found.
      
  NOTE: the script is prepared to be run under a Linux environment,
    with a Bash shell and having these programs installed:
     - swipl: SWI Prolog
     - evince: Ubuntu PDF viewer
